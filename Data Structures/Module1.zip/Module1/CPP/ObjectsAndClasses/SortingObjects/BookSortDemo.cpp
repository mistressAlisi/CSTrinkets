#include <iostream>
#include "Book.h"

using namespace std;

void insertionSort(Book[], int);
void printArray(Book[], int);

int main() {
    Book books[5];
    books[0] = Book("The Andromeda Strain", "Michael Crichton", 1969, 350);
    books[1] = Book("Jaws", "Peter Benchley", 1974, 278);
    books[2] = Book("Moby Dick", "Herman Melville", 1851, 635);
    books[3] = Book("Pet Sematary", "Stephen King", 1983, 373);
    books[4] = Book("Frankenstein", "Mary Shelley", 1818, 280);

    printArray(books, 5);           //Print before sorting
    insertionSort(books, 5);
    printArray(books, 5);           //Print after sorting

    return 0;
}

void insertionSort(Book b[], int length) {
    for(int i = 1; i < length; i++) {
		Book temp = b[i];
		int j = i-1;
		while(j >= 0 && b[j].getYearPublished() > temp.getYearPublished()) {
			b[j+1] = b[j];
			j--;
		}
		b[j+1] = temp;
	}
}

void printArray(Book b[], int length) {
    cout << "Current objects in the array: " << endl;
    for(int i = 0; i < length; i++) {
	    cout << b[i].toString() << endl;
	}
    cout << endl;
}
