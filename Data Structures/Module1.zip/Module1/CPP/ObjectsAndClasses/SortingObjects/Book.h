#include <iostream>

using namespace std;

class Book {
    private:
        int yearPublished;
        int numPages;
        string title;
        string author;

    public:
        Book() {
            title = "";
            author = "";
            yearPublished = -1;
            numPages = -1;
        }

        Book(string t, string a, int y, int n) {
            title = t;
            author = a;
            yearPublished = y;
            numPages = n;
        }

        string toString() {
            return title + "-" + author + "; Year: " + to_string(yearPublished) + ", Pages: " + to_string(numPages);
        }

        int getYearPublished() {
            return yearPublished;
        }
    
};