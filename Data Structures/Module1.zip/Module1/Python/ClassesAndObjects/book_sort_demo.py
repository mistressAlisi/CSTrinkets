
from book import Book

def insertionSort(b):
  for i in range(1, len(b)):
    temp = b[i]
    j = i-1
    while j >= 0 and b[j].get_year_published() > temp.get_year_published() :
      b[j+1] = b[j]
      j -= 1
    b[j+1] = temp


books = [];

books.append(Book("The Andromeda Strain", "Michael Crichton", 1969, 350))
books.append(Book("Jaws", "Peter Benchley", 1974, 278))
books.append(Book("Moby Dick", "Herman Melville", 1851, 635))
books.append(Book("Pet Sematary", "Stephen King", 1983, 373))
books.append(Book("Frankenstein", "Mary Shelley", 1818, 280))


print("Before sorting:")
for x in books:
  print(x.to_string())
print()

insertionSort(books)

print("After sorting:")
for x in books:
  print(x.to_string())
print()

