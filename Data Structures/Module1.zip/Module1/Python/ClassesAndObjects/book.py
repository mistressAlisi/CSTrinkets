
class Book :

    def __init__(self, t, a, y, n) :
        self.title = t
        self.author = a
        self.year_published = y
        self.num_pages = n

    def get_year_published(self) :
        return self.year_published

    def to_string(self) :
        return self.title + "-" + self.author + "; Year: " + \
        str(self.year_published) + ", Pages: " + str(self.num_pages)
