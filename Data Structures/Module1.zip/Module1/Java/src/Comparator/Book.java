package Comparator;

import java.util.Comparator;

public class Book {

    private int yearPublished;
    private int numPages;
    private String title;
    private String author;

    /**
     * Constructor
     * @param t Title
     * @param a Author
     * @param y Year Published
     * @param n Number of Pages
     */
    public Book(String t, String a, int y, int n) {
        title = t;
        author = a;
        yearPublished = y;
        numPages = n;
    }

    /**
     * Returns a descriptive string about the book object.
     * Overrides the primordial Object toString method.
     * @return String representation of a Book object
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(title);
        sb.append("-");
        sb.append(author);
        sb.append("; Year: ");
        sb.append(yearPublished);
        sb.append(", Pages: ");
        sb.append(numPages);
        return sb.toString();
    }

    /**
     * Accessor for the yearPublished field.
     * @return yearPublished
     */
    public int getYearPublished() {
        return yearPublished;
    }

    /**
     * Accessor for the numPages field.
     * @return numPages
     */
    public int getNumPages() {
        return numPages;
    }

    /**
     * Accessor for the title field.
     * @return title
     */
    public String getTitle() {
        return title;
    }
}

/**
 * Compares two books, making the comparison based on the year published (ascending order).
 *  result >= 1 when book 1's year is greater than book 2's year
 *  result <= -1 when book 1's year is less than book 2's year
 *  result = 0 when book 1's year is equal to book 2's year
 */
class SortYearAscending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b1.getYearPublished() - b2.getYearPublished();
    }
}

/**
 * Compares two books, making the comparison based on the year published (descending order).
 *  result >= 1 when book 2's year is greater than book 1's year
 *  result <= -1 when book 2's year is less than book 1's year
 *  result = 0 when book 2's year is equal to book 1's year
 */
class SortYearDescending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b2.getYearPublished() - b1.getYearPublished();
    }
}

/**
 * Class that implements Comparator to sort by title (ascending)
 */
class SortByTitleAscending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b1.getTitle().compareTo(b2.getTitle());              //Strings implement Comparable
    }
}

/**
 * Class that implements Comparator to sort by title (descending)
 */
class SortByTitleDescending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b2.getTitle().compareTo(b1.getTitle());              //Strings implement Comparable
    }
}

/**
 * Compares two books, making the comparison based on the number of pages (ascending order).
 *  result >= 1 when book 1's pages is greater than book 2's pages
 *  result <= -1 when book 1's pages is less than book 2's pages
 *  result = 0 when book 1's pages is equal to book 2's pages
 */
class SortPagesAscending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b1.getNumPages() - b2.getNumPages();
    }
}

/**
 * Compares two books, making the comparison based on the number of pages (descending order).
 *  result >= 1 when book 2's pages is greater than book 1's pages
 *  result <= -1 when book 2's pages is less than book 1's pages
 *  result = 0 when book 2's pages is equal to book 1's pages
 */
class SortPagesDescending implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b2.getNumPages() - b1.getNumPages();
    }
}
