package Comparable;

import java.util.Arrays;

public class BookSort {
    Book[] books;

    /**
     * Constructor.
     */
    public BookSort() {
        books = new Book[5];
        books[0] = new Book("The Andromeda Strain", "Michael Crichton", 1969, 350);
        books[1] = new Book("Jaws", "Peter Benchley", 1974, 278);
        books[2] = new Book("Moby Dick", "Herman Melville", 1851, 635);
        books[3] = new Book("Pet Sematary", "Stephen King", 1983, 373);
        books[4] = new Book("Frankenstein", "Mary Shelley", 1818, 280);
    }

    /**
     * Run Method.
     */
    public void run() {
        System.out.println("Unsorted objects: ");
        printArray(books);

        Arrays.sort(books);

        System.out.println("Sorted objects (by year published): ");
        printArray(books);
    }

    /**
     * Prints the contents of an array
     * @param a - Array of objects to print (implicitly calls each object's toString method)
     */
    public void printArray(Book[] a) {
        for(int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
        System.out.println();
    }

    /**
     * Main Method.
     */
    public static void main(String[] args) {
        BookSort b = new BookSort();
        b.run();
    }
}
